﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrapManager : MonoBehaviour
{
    public GameObject[] m_gameObjects;

    public int m_trapSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Freeze()
    {
        for (int i = 0; i < m_gameObjects.Length; i++)
        {
            if (m_gameObjects[i] != null) m_gameObjects[i].GetComponent<AutoMovement>().m_speed = 0;
        }
    }
}
