﻿using System.Collections.Generic;
using UnityEngine;

public class KeyDetector : MonoBehaviour
{
    public WordCollection m_wordCollection;
    public WordCollection m_resultCollection;

    // Do the incremental method first thing next week!
    public string m_memory;
   
    private void Start()
    {
        _validWords = m_wordCollection.m_words;
    }

    private void Update()
    {
        var letterPressed = GetLetterPressed();
        if (string.IsNullOrEmpty(letterPressed)) return;

        var validWords = GetValidWords(letterPressed);
        if (validWords.Length < 1) return;

        if (string.IsNullOrEmpty(_validWords[0].Substring(1)))
        {
            m_resultCollection.m_words = new string[0];
            _validWords = m_wordCollection.m_words;
        }
        else
        {
            _validWords = validWords;
            // . ; [] () ; = + - > < ! 
            m_resultCollection.m_words = new string[_validWords.Length];
            _validWords.CopyTo(m_resultCollection.m_words,0);
        }
    }

    private string GetLetterPressed()
    {
        if (Input.anyKeyDown == false) return ""; 
        
        foreach (var letter in _alphabetKeycodes)
        {
            if (!Input.GetKeyDown(letter)) continue;
            return letter.ToString().ToLower();
        }

        return "";
    }
    
    private string[] GetValidWords(string letter)
    {
        var output = new List<string>();
        
        foreach (var word in _validWords)
        {
            if (!word.StartsWith(letter))continue;
            
            Debug.Log("Word remaining:" + word.Substring(1));
            output.Add(word.Substring(1));
        }

        return output.ToArray();
    }

    private string[] _validWords;

    private KeyCode[] _alphabetKeycodes = new KeyCode[]{
        KeyCode.A, 
        KeyCode.B, 
        KeyCode.C,
        KeyCode.D,
        KeyCode.E, 
        KeyCode.F, 
        KeyCode.G,
        KeyCode.H,
        KeyCode.I, 
        KeyCode.J, 
        KeyCode.K,
        KeyCode.L,
        KeyCode.M, 
        KeyCode.N, 
        KeyCode.O,
        KeyCode.P,
        KeyCode.Q, 
        KeyCode.R, 
        KeyCode.S,
        KeyCode.T,
        KeyCode.U, 
        KeyCode.V, 
        KeyCode.W,
        KeyCode.X,
        KeyCode.Y, 
        KeyCode.Z
    };
}