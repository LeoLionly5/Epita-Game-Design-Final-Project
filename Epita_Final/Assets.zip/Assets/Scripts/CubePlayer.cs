﻿using UnityEngine;

public class CubePlayer : MonoBehaviour
{
    public string m_horizontal;
    public string m_vertical;
    
    public float m_speed = 10f;
    
    private void Start()
    {
        _transform = GetComponent<Transform>();
        _newPosition = new Vector3();
    }
    
    private void Update()
    {
        _newPosition = _transform.position;

        _newPosition.x += Input.GetAxis(m_horizontal) * m_speed * Time.deltaTime;
        _newPosition.y += Input.GetAxis(m_vertical) * m_speed * Time.deltaTime;
        
        _transform.position = _newPosition;
    }

    private Transform _transform;
    private Vector3 _newPosition;
}