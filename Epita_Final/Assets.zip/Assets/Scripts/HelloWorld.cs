﻿using UnityEngine;

public class HelloWorld : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Hello Epita !!!");        
    }
    
    void Update()
    {
        Debug.Log("weeeeee");
    }
}