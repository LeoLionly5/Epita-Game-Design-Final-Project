﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoMovement : MonoBehaviour
{
    public float m_speed;

    public float m_frequency;

    public int lastMovement = 0;

    public int frequencyCounter = 0;
    

    // Start is called before the first frame update
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        var movement = transform.position;

        //Movement
        if (frequencyCounter >= m_frequency || lastMovement == 0)
        {
            lastMovement = UnityEngine.Random.Range(1,5);
            frequencyCounter = 0;
        }

        if(movement.x < 2)
        {
            lastMovement = 1;
            frequencyCounter = 0;
        }
        else
        if(movement.x > 49)
        {
            lastMovement = 2;
            frequencyCounter = 0;
        }
        else
        if (movement.z < 17)
        {
            lastMovement = 4;
            frequencyCounter = 0;
        }
        else
        if (movement.z > 89)
        {
            lastMovement = 3;
            frequencyCounter = 0;
        }

        switch (lastMovement)
        {
            case 1:
                movement.x += m_speed * Time.deltaTime;
                movement.z += m_speed * Time.deltaTime;
                break;
            case 2:
                movement.x -= m_speed * Time.deltaTime;
                movement.z -= m_speed * Time.deltaTime;
                break;
            case 3:
                movement.x += m_speed * Time.deltaTime;
                movement.z -= m_speed * Time.deltaTime;
                break;
            case 4:
                movement.x -= m_speed * Time.deltaTime;
                movement.z += m_speed * Time.deltaTime;
                break;
        }

        transform.position = movement;
        frequencyCounter++;
    }

    private Rigidbody _rigidbody;
}
