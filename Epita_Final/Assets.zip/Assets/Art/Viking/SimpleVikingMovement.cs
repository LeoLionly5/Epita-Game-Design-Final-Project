﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Animator))]

public class SimpleVikingMovement : MonoBehaviour
{
    [Header("Animator")]
    public string m_animatorVelocityParameterX = "Pos_X";
    public string m_animatorVelocityParameterY = "Pos_Y";

    [Header("Inputs")]
    public string m_inputAxisX = "Horizontal";
    public string m_inputAxisY = "Vertical";

    // Start is called before the first frame update
    private void Start()
    {
        m_animator = GetComponent<Animator>();
        //_animatorVelocityX = Animator.StringToHash("Velocity_X");
        //_animatorVelocityY = Animator.StringToHash("Velocity_Y");
        _animatorVelocityX = Animator.StringToHash(m_animatorVelocityParameterX);
        _animatorVelocityY = Animator.StringToHash(m_animatorVelocityParameterY);
    }

    // Update is called once per frame
    private void Update()
    {
        //var velocityX = Input.GetAxis("Horizontal");
        //var velocityY = Input.GetAxis("Vertical");
        _velocity.x = Input.GetAxis(m_inputAxisX);
        _velocity.y = Input.GetAxis(m_inputAxisY);

        //m_animator.SetFloat("Velocity_X", velocityX);
        //m_animator.SetFloat("Velocity_Y", velocityY);
        m_animator.SetFloat(_animatorVelocityX, _velocity.x);
        m_animator.SetFloat(_animatorVelocityY, _velocity.y);
    }

    public Animator m_animator;

    private int _animatorVelocityX;
    private int _animatorVelocityY;

    private Vector2 _velocity;
}
