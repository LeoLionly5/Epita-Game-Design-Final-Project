﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExtraMovement : MonoBehaviour
{
    public int frequencyCounter = 0;
    public bool currentMovement = true;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var movement = transform.position;

        

        //Movement

        if (currentMovement)
        {
            movement.x += 2 * Time.deltaTime;
        }
        else
        {
            movement.x -= 2 * Time.deltaTime;
        }

        if (frequencyCounter > 300)
        {
            frequencyCounter = 0;
            if (currentMovement)
            {
                currentMovement = false;
            }
            else
            {
                currentMovement = true;
            }
        }

        transform.position = movement;
        frequencyCounter++;
    }
}
