﻿using UnityEngine;

[CreateAssetMenu]
public class WordCollection : ScriptableObject
{
    public string[] m_words;
}