﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class yourDevil : MonoBehaviour
{
    public AudioSource[] m_audioSources;

    public int m_currentLevel;



    public void LevelUp()
    {
        //m_currentLevel = 5;
        //m_audioSources[0].volume = 5;
        if (m_currentLevel < m_audioSources.Length)
        {
            //m_currentLevel ++;
            m_currentLevel = 5; // 跟老师不一样
        }
    }

    public void LevelDown()
    {
        if (m_currentLevel > 0)
        {
            //m_currentLevel --;
            m_currentLevel = 0; // 跟老师不一样
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        for (int i = 0; i < m_audioSources.Length; i++)
        {
            if (m_currentLevel > i)
            {
                m_audioSources[i].volume += Time.deltaTime;
                continue;
            }

            m_audioSources[i].volume -= Time.deltaTime;
        }
    }
}
