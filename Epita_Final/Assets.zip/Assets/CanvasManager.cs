﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class CanvasManager : MonoBehaviour
{
    public TextMeshProUGUI textMeshPro;
    private int score;

    void Start()
    {
        score = 0;
    }

    void Update()
    {

    }

    public void ScoreUp()
    {
        score++;
        textMeshPro.text = "Bonus: " + score.ToString();
    }

    public void ScoreDown()
    {
        if (score>0) score--;
        textMeshPro.text = "Bonus: " + score.ToString();
    }

    public void EndGame()
    {
        textMeshPro.text = "Congratulation! Your final bonus: " + score.ToString();
    }
}
