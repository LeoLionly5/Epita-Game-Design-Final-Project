﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float m_speed;
    public float m_jumpForce;

    // Start is called before the first frame update
    void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        var movement = transform.position;

        // Jump
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //movement.y += 2f;
            _rigidbody.AddForce(Vector3.up * m_jumpForce);
        }

        //Movement

        var movementX = Camera.main.transform.right * Input.GetAxisRaw("Horizontal") * m_speed * Time.deltaTime;
        var movementZ = Camera.main.transform.forward * Input.GetAxisRaw("Vertical") * m_speed * Time.deltaTime;

        var finalRelativeMovement = movementX + movementZ;

        movement.x += Input.GetAxisRaw("Horizontal") * m_speed * Time.deltaTime;
        movement.z += Input.GetAxisRaw("Vertical") * m_speed * Time.deltaTime;

        transform.position = transform.position + finalRelativeMovement;

    }

    private Rigidbody _rigidbody;
}
