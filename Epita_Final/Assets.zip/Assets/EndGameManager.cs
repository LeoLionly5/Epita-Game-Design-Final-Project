﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EndGameManager : MonoBehaviour
{
    public TextMeshProUGUI textMeshPro;

    void Start()
    {
        textMeshPro.text = "";
    }

    void Update()
    {

    }

    public void EndGame()
    {
        textMeshPro.text = "Good job !";
    }
}
